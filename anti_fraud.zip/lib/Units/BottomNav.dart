


import 'package:anti_fraud/Pages/Page_kwzd.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Pages/MyHomePage.dart';
import '../Pages/Page_about.dart';
import '../Pages/Page_gxh.dart';
import '../Pages/Page_hwr.dart';
import '../Pages/Page_jgdrz.dart';
import '../Pages/Page_ljrz.dart';
import '../Pages/Page_lmsd.dart';
import '../Pages/Page_tbch.dart';
import '../Pages/Page_tq.dart';
import '../Pages/Page_tswc.dart';
import '../Pages/Page_wqjd.dart';
import '../Pages/Page_wxzp.dart';
import '../Pages/Page_xjxc.dart';
import '../Pages/Page_xzss.dart';
import '../Pages/Page_zywj.dart';


class BottomNav extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.bottomCenter,
      //color: Colors.blue,
      child: Center(
          child:  Column(
            children: [
              TextButton(
                onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                return  MyHomePage();
                }));
                },
                child: Text('返回首页',style: TextStyle(fontSize: 20),)),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [

                  Column(
                    children: [
                      TextButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) {
                              return Page_kwzd();
                            }));
                          },
                          child: Text('狂妄自大',style: TextStyle(fontSize: 15),)),
                      TextButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) {
                              return Page_wqjd();
                            }));
                          },
                          child: Text('歪曲解读',style: TextStyle(fontSize: 15),)),
                      TextButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) {
                              return Page_wxzp();
                            }));
                          },
                          child: Text('无限诈骗',style: TextStyle(fontSize: 15),)),
                      TextButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) {
                              return Page_gxh();
                            }));
                          },
                          child: Text('狗循环',style: TextStyle(fontSize: 15),)),
                      TextButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) {
                              return Page_ljrz();
                            }));
                          },
                          child: Text('垃圾日杂',style: TextStyle(fontSize: 15),)),
                      TextButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) {
                              return Page_tbch();
                            }));
                          },
                          child: Text('挑拨仇恨',style: TextStyle(fontSize: 15),)),
                      TextButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) {
                              return Page_xjxc();
                            }));
                          },
                          child: Text('虚假宣传',style: TextStyle(fontSize: 15),)),

                    ],
                  ),
                  Column(
                    children: [
                      TextButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) {
                              return Page_zywj();
                            }));
                          },
                          child: Text('转移危机',style: TextStyle(fontSize: 15),)),
                      TextButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) {
                              return Page_xzss();
                            }));
                          },
                          child: Text('虚张声势',style: TextStyle(fontSize: 15),)),
                      TextButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) {
                              return Page_jgdrz();
                            }));
                          },
                          child: Text('金狗的日债',style: TextStyle(fontSize: 15),)),
                      TextButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) {
                              return Page_tq();
                            }));
                          },
                          child: Text('偷窃',style: TextStyle(fontSize: 15),)),
                      TextButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) {
                              return Page_lmsd();
                            }));
                          },
                          child: Text('两面三刀',style: TextStyle(fontSize: 15),)),
                      TextButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) {
                              return Page_hwr();
                            }));
                          },
                          child: Text('核污染',style: TextStyle(fontSize: 15),)),
                      TextButton(
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) {
                              return Page_tswc();
                            }));
                          },
                          child: Text('天生无耻',style: TextStyle(fontSize: 15),)),

                    ],
                  ),
                ],
              )
            ],
          ),
      ),
    );
  }
}