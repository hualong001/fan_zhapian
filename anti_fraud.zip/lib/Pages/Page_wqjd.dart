import 'package:anti_fraud/Units/MyAppBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Words/WordBox.dart';
import '../Words/WordLayout.dart';



List<String> wordlistbox_kwzd= [
  "因为日狗狂妄自大不自重；因为无论中国人做什么，日狗都爱跟自己乱扯；",
  "所以为了便于区别，日本人统一叫“狗”，并不是骂人；",
  "没有说“狗”，就表示没有说日本人；",
  "真想歪曲解读，理解一下“日狗集体自杀”",
];

String str = "因为日狗爱诈骗，所以大家做什么都不用对日狗负责!";

TextStyle textBoxStyle1 = const TextStyle(
  fontSize: 25,
  color: Colors.black,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);
TextStyle textBoxStyle2 = const TextStyle(
  fontSize: 25,
  color: Colors.deepPurple,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);

TextStyle StrStyle = const TextStyle(
  fontSize: 20,
  color: Colors.redAccent,
  fontWeight: FontWeight.bold,
  fontStyle: FontStyle.normal,
);

class Page_wqjd extends StatelessWidget{
  const Page_wqjd({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: "歪曲解读"),
      floatingActionButton: ShowBottomSheet(),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Center(
            child: Column(
              children: [
                const SizedBox(height: 10,),
                WordBox(items: wordlistbox_kwzd, textStyle1: textBoxStyle1, textStyle2:textBoxStyle2,),
                const SizedBox(height: 20,),
                Words(words: str, textStyle: StrStyle,),
              ],
            )
        ),
      )
    );
  }
}
