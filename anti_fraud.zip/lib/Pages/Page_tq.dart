import 'package:anti_fraud/Units/MyAppBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Words/WordBox.dart';
import '../Words/WordLayout.dart';

List<String> wordlist_kwzd= [
  "盗用别人的身份；",
  "偷取别人的知识成果与财产；",
  "日狗在南京寺庙偷偷藏着日本战犯的牌位，想以此证明中国人接受了日狗，这跟偷偷盗用我的证件购买疯狗的车还给疯狗的车买保险是一样的无耻",
  "若去日狗的商店消费， 日狗就认为你打算做日本人，并以此为理由对你进行偷窃与抹黑，对外乱打广告说你是日家的；",
  "有的日狗通过打广告或者心里暗示捏造虚假的关系，对别人进行偷窃与诈骗； ",
  "说什么我有狗金，说狗是我的， 其实我完全不知道，跟我完全无关"
];

List<String> wordlistbox_kwzd= [
  "私自替别人决策",
  "私自帮别人选择一手烂牌，让别人输；",
  "“用别人的钱，帮别人做事，实现自己的目标”，",
  "和珅这个鸟人的歪心思；",
  "私自打着别人的旗号打击别人所谓的竞争对手，实则是制造仇恨，实现自己的目的；在中美竞争的一些领域，日狗最敏感，最兴奋，往往是当事人还没有表态，日狗就开始急不可耐的打着中美双方的幌子互相攻击制造仇恨了。"
];

TextStyle textStyle1 = const TextStyle(
  color: Colors.redAccent,
  fontSize: 20,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);
TextStyle textStyle2 = const TextStyle(
  color: Colors.black54,
  fontSize: 17,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);

TextStyle textBoxStyle1 = const TextStyle(
  fontSize: 17,
  color: Colors.black,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);
TextStyle textBoxStyle2 = const TextStyle(
  fontSize: 15,
  color: Colors.deepPurple,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);

TextStyle StrStyle = const TextStyle(
  fontSize: 15,
  color: Colors.brown,
  fontWeight: FontWeight.bold,
  fontStyle: FontStyle.normal,
);

class Page_tq extends StatelessWidget{
  const Page_tq({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: "偷窃"),
      floatingActionButton: ShowBottomSheet(),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Center(
            child: Column(
              children: [
                const SizedBox(height: 20,),
                WordsList(items: wordlist_kwzd, textStyle1: textStyle1, textStyle2: textStyle2,),
                const SizedBox(height: 50,),
                WordBox(items: wordlistbox_kwzd, textStyle1: textBoxStyle1, textStyle2:textBoxStyle2,),
              ],
            )
        ),
      )
    );
  }
}
