import 'package:anti_fraud/Units/MyAppBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Words/WordBox.dart';
import '../Words/WordLayout.dart';

List<String> wordlist_kwzd= [
  "日狗不遗余力的在全球推销与安插自己的日杂，妄想用日杂窃取他国财富与权势，以日狗的狗性，定是给每个国家重要人物都准备了一堆日杂；",
  "日狗用所有力量扶持一个日杂或者某个行业中的领头公司， 再借此控制或者影响其他人或者其他公司",
  "日狗生产制造出来的大量日杂，消耗的是其他国家的信誉，实现自己的勾当",
  "eg: 日杂在中国装a，拿a做保护伞，好事算自己的，坏事算到a头上；日杂在其他国家装“中”，也是同样的套路",
  "日杂a,  日杂0，日杂金，日杂中…"
];

List<String> wordlistbox_kwzd= [
  " 无论日狗有什么伪装或者借口， 都没有凌驾于中国人之上的权力，",
  "见到这些狗头拆掉就行， 狗头偶尔会表现的很凶狠，一般都坚持不了几天。",
  "日杂一般都只是日狗的傀儡，的确有一部分人很享受做傀儡一样的日王，",
  "除了被日狗吹的忘记自我，对日本却是没有一点实权，本质上是妥妥的日狗。"
];

TextStyle textStyle1 = const TextStyle(
  color: Colors.redAccent,
  fontSize: 20,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);
TextStyle textStyle2 = const TextStyle(
  color: Colors.black54,
  fontSize: 17,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);

TextStyle textBoxStyle1 = const TextStyle(
  fontSize: 17,
  color: Colors.black,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);
TextStyle textBoxStyle2 = const TextStyle(
  fontSize: 12,
  color: Colors.deepPurple,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);

TextStyle StrStyle = const TextStyle(
  fontSize: 15,
  color: Colors.brown,
  fontWeight: FontWeight.bold,
  fontStyle: FontStyle.normal,
);

class Page_ljrz extends StatelessWidget{
  const Page_ljrz({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: "垃圾日杂"),
      floatingActionButton: ShowBottomSheet(),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Center(
            child: Column(
              children: [
                const SizedBox(height: 10,),
                WordsList(items: wordlist_kwzd, textStyle1: textStyle1, textStyle2: textStyle2,),
                const SizedBox(height: 10,),
                WordBox(items: wordlistbox_kwzd, textStyle1: textBoxStyle1, textStyle2:textBoxStyle2,),
              ],
            )
        ),
      )
    );
  }
}
