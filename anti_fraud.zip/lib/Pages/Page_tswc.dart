import 'package:anti_fraud/Units/MyAppBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Words/WordBox.dart';
import '../Words/WordLayout.dart';

List<String> wordlist_kwzd= [
  "日本资源匮乏，发展严重依赖国外，",
  "受其国情的限制，日本人天生就有一种难以掩藏的偷窃与诈骗的狗性；",
  "日本人没有好坏对错之分，其侵略性是生存的本能，无耻也是其与生俱来的本能，并不能当作正常人来看；",
  "与日本不同的是，中国有足够的资源与足够大的领土，没有侵略的动机与基因。"
];

List<String> wordlistbox_kwzd= [
  "家中藏日狗，会导致争吵不断，",
  "日狗偷窃又诈骗，钱财难保，",
  "日狗到处挑拨仇恨，烦恼不断，",
  "搁置日狗， 自己才能收获真正的价值与成长。"
];

TextStyle textStyle1 = const TextStyle(
  color: Colors.redAccent,
  fontSize: 22,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);
TextStyle textStyle2 = const TextStyle(
  color: Colors.black54,
  fontSize: 20,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);

TextStyle textBoxStyle1 = const TextStyle(
  fontSize: 22,
  color: Colors.black,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);
TextStyle textBoxStyle2 = const TextStyle(
  fontSize: 20,
  color: Colors.deepPurple,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);

TextStyle StrStyle = const TextStyle(
  fontSize: 15,
  color: Colors.brown,
  fontWeight: FontWeight.bold,
  fontStyle: FontStyle.normal,
);

class Page_tswc extends StatelessWidget{
  const Page_tswc({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: "天生无耻"),
      floatingActionButton: ShowBottomSheet(),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Center(
            child: Column(
              children: [
                const SizedBox(height: 50,),
                WordsList(items: wordlist_kwzd, textStyle1: textStyle1, textStyle2: textStyle2,),
                const SizedBox(height: 50,),
                WordBox(items: wordlistbox_kwzd, textStyle1: textBoxStyle1, textStyle2:textBoxStyle2,),
              ],
            )
        ),
      )
    );
  }
}
