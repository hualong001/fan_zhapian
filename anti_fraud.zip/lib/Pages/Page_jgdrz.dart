import 'package:anti_fraud/Units/MyAppBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Words/WordBox.dart';
import '../Words/WordLayout.dart';

List<String> wordlist_kwzd= [
  "孽畜金私自打着旅行团（打着重要人物旗号开办的旅行社，旅行条款是拒绝东北人参团，）的旗号伺机造地域歧视，妄想制造中国内部仇恨与分裂；",
  "日历金与 三烟 跑到小学 骗小学生的钱 挖红薯，穷到什么地步！无耻到什么程度！",
  "疫情期间打着政府的旗号乱封锁，乱打疫苗，打了疫苗还天天搞核酸检测，张核子假借别人的旗号开核酸检测公司，做坏事还想栽赃陷害",
];

List<String> wordlistbox_kwzd= [
  "金狗0搞的小学毒教材,全世界了解一下这个孽畜！",
  "金狗的野心还挺大,找了个日本爸爸,\n既想征服美国,又想管中国",
];

List<String> wordlist_jgdrz= [
  "一个'金牛子'的幼儿园,强迫小孩全身穿金色帽子与衣服"  ,
];

List<String> wordlistbox_mh= [
  "精狗做坏事还总爱打着重要人物的旗号！",
  "一是拿重要人物做保护伞",
  "二是伺机抹黑重要人物",
];

TextStyle textStyle1 = const TextStyle(
  color: Colors.redAccent,
  fontSize: 15,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);
TextStyle textStyle2 = const TextStyle(
  color: Colors.black54,
  fontSize: 15,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);

TextStyle textBoxStyle1 = const TextStyle(
  fontSize: 15,
  color: Colors.black,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);
TextStyle textBoxStyle2 = const TextStyle(
  fontSize: 15,
  color: Colors.deepPurple,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);

TextStyle StrStyle = const TextStyle(
  fontSize: 12,
  color: Colors.blueAccent,
  fontWeight: FontWeight.bold,
  fontStyle: FontStyle.normal,
);

class Page_jgdrz extends StatelessWidget{
  const Page_jgdrz({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: "金狗的日债"),
      floatingActionButton: ShowBottomSheet(),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Center(
            child: Column(
              children: [
                const SizedBox(height: 5,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Image(width:150,image: AssetImage('assets/images/djc.png')),
                    Image(width:150,image: AssetImage('assets/images/dnf.png')),
                  ],
                ),
                const SizedBox(height: 10,),
                WordBox(items: wordlistbox_kwzd, textStyle1: textBoxStyle1, textStyle2:textBoxStyle2,),
                const SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Image(width:150,image: AssetImage('assets/images/jgdrz.png')),
                    //Words(words: jgdrz, textStyle: StrStyle,),
                  ],
                ),
                const SizedBox(height: 10,),
                WordBox(items: wordlist_jgdrz, textStyle1: textBoxStyle1, textStyle2:textBoxStyle2,),

                WordsList(items: wordlist_kwzd, textStyle1: textStyle1, textStyle2: textStyle2,),
                const SizedBox(height: 10,),
                WordBox(items: wordlistbox_mh, textStyle1: textBoxStyle1, textStyle2:textBoxStyle2,),

              ],
            )
        ),
      )
    );
  }
}
