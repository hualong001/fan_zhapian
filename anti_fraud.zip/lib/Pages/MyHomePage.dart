import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Units/MyAppBar.dart';

class MyHomePage extends StatefulWidget {

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: '罪国日本与金狗',),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image(image: AssetImage('assets/images/dog.png')),
            SizedBox(height: 50,),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  children: [
                    TextButton(
                        onPressed: (){
                          Navigator.pushNamed(
                            context,
                            'kwzd',    //routeName
                          );
                        },
                        child: Text("狂妄自大")),
                    TextButton(
                        onPressed: (){
                          Navigator.pushNamed(
                            context,
                            'wqjd',    //routeName
                          );
                        },
                        child: Text("歪曲解读")),
                    TextButton(
                        onPressed: (){
                          Navigator.pushNamed(
                            context,
                            'wxzp',    //routeName
                          );
                        },
                        child: Text("无限诈骗")),
                    TextButton(
                        onPressed: (){
                          Navigator.pushNamed(
                            context,
                            'gxh',    //routeName
                          );
                        },
                        child: Text("狗循环")),
                    TextButton(
                        onPressed: (){
                          Navigator.pushNamed(
                            context,
                            'ljrz',    //routeName
                          );
                        },
                        child: Text("垃圾日杂")),
                    TextButton(
                        onPressed: (){
                          Navigator.pushNamed(
                            context,
                            'tbch',    //routeName
                          );
                        },
                        child: Text("挑拨仇恨")),
                    TextButton(
                        onPressed: (){
                          Navigator.pushNamed(
                            context,
                            'xjxc',    //routeName
                          );
                        },
                        child: Text("虚假宣传")),
                  ],

                ),
                Column(
                  children: [
                    TextButton(
                        onPressed: (){
                          Navigator.pushNamed(
                            context,
                            'zywj',    //routeName
                          );
                        },
                        child: Text("转移危机")),
                    TextButton(
                        onPressed: (){
                          Navigator.pushNamed(
                            context,
                            'xzss',    //routeName
                          );
                        },
                        child: Text("虚张声势")),
                    TextButton(
                        onPressed: (){
                          Navigator.pushNamed(
                            context,
                            'jgdrz',    //routeName
                          );
                        },
                        child: Text("金狗的日债")),
                    TextButton(
                        onPressed: (){
                          Navigator.pushNamed(
                            context,
                            'tq',    //routeName
                          );
                        },
                        child: Text("偷窃")),
                    TextButton(
                        onPressed: (){
                          Navigator.pushNamed(
                            context,
                            'lmsd',    //routeName
                          );
                        },
                        child: Text("两面三刀")),
                    TextButton(
                        onPressed: (){
                          Navigator.pushNamed(
                            context,
                            'hwr',    //routeName
                          );
                        },
                        child: Text("核污染")),
                    TextButton(
                        onPressed: (){
                          Navigator.pushNamed(
                            context,
                            'tswc',    //routeName
                          );
                        },
                        child: Text("天生无耻")),
                  ],
                )
              ],
            ),
            TextButton(
                onPressed: (){
                  Navigator.pushNamed(
                    context,
                    'zj',    //routeName
                  );
                },
                child: Text(style: TextStyle(fontSize: 20),"罪国日本")),
          ],
        ),
      ),
    );
  }
}
