import 'package:anti_fraud/Units/MyAppBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Words/WordBox.dart';
import '../Words/WordLayout.dart';

List<String> wordlist_kwzd= [
  "日狗惯用的心理暗示诈骗就是：\n某人有日狗，某人爱狗，某人优狗，金狗优惠0元学，某人归狗了，某人疯了，某狗好厉害，狗保人，某某永狗，狗起某某，狗正仁狗，向日狗，狗恒，狗永生，某人抢狗抢小三抢疯了，假如中美开狗了…",
  "这个某人是日狗自己意淫出来的（并不存在）；其实除了日狗自己爱打广告说别人爱狗，真没有其他人把日狗当人看",
  "有的时候是想抹黑某人，有的时候是假借某人的信誉骗别人也买条狗。",
  "广告都是预先准备好的，完整的一套诈骗套路，最后再找个地方点播一首“日不落”，心虚的宽慰一下忙了一天的狗子。",
  "日狗还爱捏造或者恶意宣传其他国家的冲突与矛盾的新闻，总想置其他国家于冲突不断的境地； 所以大家务必警惕日狗的险恶用心， 不必为了日狗去背锅垫背。",
  "假冒党政机关工作人员进行诈骗...用黑客强行篡改新闻媒体进行诈骗..."
];

List<String> wordlistbox_kwzd= [
  "我猜很多重要人物都见过日狗的这一套，务必让大家了解日狗的诈骗伎俩。",
  "通常这些新闻的背后都有不少的陷阱，大家去查的时候需要保持清醒，日狗会把不相关的重要人物也拉进来，",
  "一是让大家畏惧不敢查， 二是栽赃陷害重要人物",
];

String str = "日狗这些突兀的广告恰恰反应了日狗的不自信!";

TextStyle textStyle1 = const TextStyle(
  color: Colors.redAccent,
  fontSize: 20,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);
TextStyle textStyle2 = const TextStyle(
  color: Colors.black54,
  fontSize: 12,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);

TextStyle textBoxStyle1 = const TextStyle(
  fontSize: 17,
  color: Colors.black,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);
TextStyle textBoxStyle2 = const TextStyle(
  fontSize: 20,
  color: Colors.deepPurple,
  fontWeight: FontWeight.normal,
  fontStyle: FontStyle.normal,
);

TextStyle StrStyle = const TextStyle(
  fontSize: 15,
  color: Colors.brown,
  fontWeight: FontWeight.bold,
  fontStyle: FontStyle.normal,
);

class Page_wxzp extends StatelessWidget{
  const Page_wxzp({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: "无限诈骗"),
      floatingActionButton: ShowBottomSheet(),
      body: Container(
        padding: EdgeInsets.all(10),
        child: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 10,),
                WordsList(items: wordlist_kwzd, textStyle1: textStyle1, textStyle2: textStyle2,),
                const SizedBox(height: 10,),
                WordBox(items: wordlistbox_kwzd, textStyle1: textBoxStyle1, textStyle2:textBoxStyle2,),
                const SizedBox(height: 20,),
                Words(words: str, textStyle: StrStyle,),
              ],
            )
        ),
      )
    );
  }
}
