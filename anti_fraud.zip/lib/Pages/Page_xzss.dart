import 'package:anti_fraud/Units/MyAppBar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Units/AppBottomSheet.dart';
import '../Words/WordBox.dart';
import '../Words/WordLayout.dart';

List<String> wordlist_kwzd= [
  "爱找爹，乱找爹，找不到爹的时候捏造一个爹，爱打着爹的旗号做坏事栽赃陷害；",
  "通过不断伪造与重要人物的虚假的亲密关系，给自己造保护伞，获取不正当收益，同时打击抹黑重要人物。",
  "没有大国的支持，疯狗跳不起来！",
];



TextStyle textStyle1 = const TextStyle(
  color: Colors.redAccent,
  fontSize: 17,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);
TextStyle textStyle2 = const TextStyle(
  color: Colors.black54,
  fontSize: 17,
  fontWeight: FontWeight.w700,
  fontStyle: FontStyle.normal,
);

class Page_xzss extends StatelessWidget{
  const Page_xzss({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: MyAppBar(pagetitle: "虚张声势"),
      floatingActionButton: ShowBottomSheet(),
      body: Container(
        padding: EdgeInsets.all(10),
        child: SingleChildScrollView(
            child: Column(
              children: [
                const SizedBox(height: 10,),
                Image(image: AssetImage('assets/images/xzss.png')),
                const SizedBox(height: 50,),
                WordsList(items: wordlist_kwzd, textStyle1: textStyle1, textStyle2: textStyle2,),
              ],
            )
        ),
      )
    );
  }
}
