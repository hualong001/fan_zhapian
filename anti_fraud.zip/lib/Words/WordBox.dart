

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'WordLayout.dart';

void main(){
  List<String> wordlist_kwzd= [
    "自封为王",
    "自命为天人",
    "爱给自己贴金",
    "自称霸权"
  ];

  TextStyle testStyle1 = const TextStyle(
    fontSize: 20,
    color: Colors.redAccent,
    fontWeight: FontWeight.normal,
    fontStyle: FontStyle.normal,
  );
  TextStyle testStyle2 = const TextStyle(
    fontSize: 20,
    color: Colors.blueAccent,
    fontWeight: FontWeight.normal,
    fontStyle: FontStyle.normal,
  );

  runApp(
    MaterialApp(
      home: Scaffold(
        body: Center(
            child: WordBox(items: wordlist_kwzd, textStyle1: testStyle1, textStyle2: testStyle2,)
        ),
      ),
    )
  );
}



class WordBox extends StatelessWidget{
  final List<String> items;
  final TextStyle textStyle1;
  final TextStyle textStyle2;
  const WordBox({super.key, required this.items, required this.textStyle1,required this.textStyle2});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 450,
      padding: const EdgeInsets.all(7),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        border: Border.all(
          color: Colors.blueAccent,
          width: 7,
        )
      ),
      //color: Colors.blue,
      child:WordsList(items: items, textStyle1: textStyle1,textStyle2: textStyle2,),
    );
  }
}