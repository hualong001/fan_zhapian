


import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main(){
  List<String> wordlist= ["1","2","3","4"];

  runApp(
    MaterialApp(
      home: Scaffold(
        body: Wordlist(items: wordlist,),
      ),
    ),
  );
}

//不能嵌套
class Wordlist extends StatelessWidget {
  final List<String> items;

  const Wordlist({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(    //不能嵌套
      scrollDirection: Axis.vertical,
      itemCount: items.length,
      // prototypeItem: ListTile(
      //   title: Text(items.first),
      // ),
      itemBuilder: (context, index) {
        return ListTile(
          title: Text(items[index]),
        );
      },
    );
  }
}

class SetWord extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Text(
      ""
    );
  }

}