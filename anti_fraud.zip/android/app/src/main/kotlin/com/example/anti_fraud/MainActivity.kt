package com.example.anti_fraud

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
